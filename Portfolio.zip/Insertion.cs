﻿using System;
namespace $safeprojectname$
{
    class Insertion
    {
        /*static void Main(string[] args)
        {
            int[] arr = new int[5] { 73, 16, 22, 4, 39 };
            int i;
            Console.WriteLine("Array contains: ");
            for (i = 0; i < 5; i++)
            {
                Console.WriteLine(arr[i]);
            }
            insertsort(arr, 5);
            Console.WriteLine("Sorted Array contains: ");
            for (i = 0; i < 5; i++)
                Console.WriteLine(arr[i]);
            Console.ReadLine();
        }
        static void insertsort(int[] data, int n)
        {
            int i, j;
            for (i = 1; i < n; i++)
            {
                int item = data[i];
                int ins = 0;
                for (j = i - 1; j >= && ins != 1;)
                {
                    if (item < data[j])
                    {
                        data[j + 1] = data[j];
                        j--;
                        data[j + 1] = item;
                    }
                    else ins = 1;
                }
            }
        }*/
    }
}
