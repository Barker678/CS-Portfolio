﻿

namespace $safeprojectname$
{
    class QuickSort
    {
       /* private int[] array = new int[20];
        private int len;

        public void QuickAlgorithm()
        {
            quick(0, len - 1);
        }
        public bool quick(int left, int right)
        {
            int pivot, leftend, rightend;

            leftend = left;
            rightend = right;
            pivot = array[left];

            while (left < right)
            {
                while (array[right] >= pivot) _ = (left < right);
                {
                    right--;
                }
                if (left != right)
                {
                    array[left] = array[right];
                    left++;
                }
                while (array[left] >= pivot) _ = (left < right);
                    {
                    left++;
                }
                if (left != right)
                {
                    array[right] = array[left];
                    right--;
                }
            }
            array[left] = pivot;
            pivot = left;
            left = leftend;
            right = rightend;

            if (left < pivot) { quick(left, pivot - 1); }
            if (right > pivot)
            {
                quick(pivot + 1, right);
            }
        }*/
    }

}
